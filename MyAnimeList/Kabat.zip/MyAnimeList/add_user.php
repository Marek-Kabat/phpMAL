<?php

include 'conn.php';

//  Registrace uÃ…Â¾ivatele
if(isset($_POST['submit'])) {
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];
    $email = $_POST['email'];
    $Tel = $_POST['Tel'];
    $Location = $_POST['Location'];
    $IDInfo = $conn->insert_id;
    $IDUser = $conn->insert_id;

    $sql = "INSERT INTO Information (idInformation, Tel, Location) VALUES ('$IDInfo', '$Tel', '$Location')";
    if ($conn->query($sql) === TRUE) {
        echo "Registration successful. <br>";
        $IDInfo_User = $conn->insert_id;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
// PÃ…â„¢ÃƒÂ­kaz pro databÃƒÂ¡zi

$sql = "INSERT INTO User (idUser, UserName, Password, Email, Information_idInformation) VALUES ('$IDUser', '$Username', '$Password', '$email', '$IDInfo_User')";
if ($conn->query($sql) === TRUE) {
    $_SESSION['username'] = $Username;
    echo "<p>Welcome, ".$_SESSION['username']."</p>";

    echo '<br> <a href="Profile.php">click here to continue</a> <br>';
}


?>
