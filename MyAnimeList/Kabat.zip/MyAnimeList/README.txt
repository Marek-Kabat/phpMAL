Tento projekt je v rozdelanem stavu

Momantalne ano, vim, stranky nevypadaji 2x hezky ale, toto je vec kterou budu resit ke konci, az bude vse fungovat.
Databazi mam vytvorenou, cekaji ji jeste nejake zmeny ale je uz v podstate skoro finalni a funguje na hostingu
Ale to hlavni... PHP, to je momentalne ve stavu ze funguje konektor, dale se uzivatel muze prihlasit a registrovat a pote by mel videt na profilu sve jmeno, take na strance anime search mi funguje vyhledavani presnych nazvu anime a vyhledavani dle zanru je ve stavu kdy to neco dela, vypise to anime ktere se v zanru vyskytuji, ale pouze jedno, na tomto momentalne pracuji.
toto je vse, doufam ze se libi 