<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'conn.php';?>
    <link rel="stylesheet" href="navbar.css">

    <style>

    </style>
</head>
<body>
<div id="navbar" style="top: 0">
    <div  style="margin: auto; padding-bottom: 1px">
        <a style="float: left" href="Index.php">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
        <a style="float: right" href="Profile.php">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
    </div>
    <div class="col-12">
        <div  class="dropdown">
            <button class="dropbtn">Anime
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content" >
                <a href="SearchGendre.php">Anime search</a>
                <a href="TopAnime">Top anime</a>
                <a href="NewAnime">New anime</a>
            </div>
        </div>

        <a href="#">About us</a>
        <a href="#">Help</a>
        <div>
            <a class="col-1" href="Login.php" style="float: right">Login</a>
            <a href="Register.php" style="float: right">Register</a>
        </div>

    </div>
</div>
<div id="placeholder"> </div>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        stickyNavbar();
    });

    window.onscroll = function () {
        stickyNavbar();
    };

    var navbar = document.getElementById("navbar");
    var placeholder = document.getElementById("placeholder");
    var sticky = navbar.offsetTop;

    function stickyNavbar() {
        if (window.scrollY >= sticky) {
            navbar.classList.add("sticky");
            placeholder.style.display = "block";
            placeholder.style.height = navbar.offsetHeight + "px";
        } else {
            navbar.classList.remove("sticky");
            placeholder.style.display = "none";
        }
    }
</script>
<h1>Login</h1>
<form action="logindata.php" method="POST">
    <label for="Username">Username:</label><br>
    <input type="text" id="Username" name="Username"><br>

    <label for="Password">Password:</label><br>
    <input type="Password" id="Password" name="Password"><br>

    <input type="submit" value="Login">
</form>


<footer class="col-12">
    <a>doplnit kontakty, atd.</a>
</footer>
</body>
</html>