<!DOCTYPE html>
<html>
<head>
    <title>SearchGenre</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="navbar.css">
    <?php include 'conn.php';?>

    <style>

    </style>
</head>
<body>

<div id="navbar" style="top: 0">
    <div  style="margin: auto; padding-bottom: 1px">
        <a style="float: left" href="Index.php">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
        <a style="float: right" href="Profile.php">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
    </div>
    <div class="col-12">
        <div  class="dropdown">
            <button class="dropbtn">Anime
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content" >
                <a href="SearchGenre.php">Anime search</a>
                <a href="TopAnime">Top anime</a>
                <a href="NewAnime">New anime</a>
            </div>
        </div>

        <a href="#">About us</a>
        <a href="#">Help</a>
        <div>
            <a class="col-1" href="Login.php" style="float: right">Login</a>
            <a href="Register.php" style="float: right">Register</a>
        </div>

    </div>
</div>
<div id="placeholder"> </div>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        stickyNavbar();
    });

    window.onscroll = function () {
        stickyNavbar();
    };

    var navbar = document.getElementById("navbar");
    var placeholder = document.getElementById("placeholder");
    var sticky = navbar.offsetTop;

    function stickyNavbar() {
        if (window.scrollY >= sticky) {
            navbar.classList.add("sticky");
            placeholder.style.display = "block";
            placeholder.style.height = navbar.offsetHeight + "px";
        } else {
            navbar.classList.remove("sticky");
            placeholder.style.display = "none";
        }
    }
</script>

<header>
    <h1>Search</h1>
</header>
<div class="search-box">
    <form action="Search.php" method="POST">
        <label for="search">search:</label><br>
        <input type="search" id="search" name="search">

    </form>

</div>
<div>

    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Drama"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Action"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Adventure"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Comedy"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Horror"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Romance"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Mystery"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Sliceoflife"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="SciFi"><br>
    </form>
    </div>
    <div class="col-2">
    <form action="Genre.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Supernatural"><br>
    </form>
    </div>
</div>



<footer class="col-12">
    <a>doplnit kontakty, atd.</a>
</footer>

<!--<script>-->
<!--    function Genre(genre){-->
<!--        $_SESSION['genre'] = genre;-->
<!---->
<!--    }-->
<!---->
<!--</script>-->
</body>
</html>