<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'conn.php';?>
    <link rel="stylesheet" href="navbar.css">

    <style>

    </style>
</head>
<body>

<div id="navbar" style="top: 0">
    <div  style="margin: auto; padding-bottom: 1px">
        <a style="float: left" href="Index.html">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
        <a style="float: right" href="Profile.html">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
    </div>
    <div class="col-12">
        <div  class="dropdown">
            <button class="dropbtn">Anime
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content" >
                <a href="SearchGendre.html">Anime search</a>
                <a href="TopAnime">Top anime</a>
                <a href="NewAnime">New anime</a>
            </div>
        </div>

        <a href="#">About us</a>
        <a href="#">Help</a>
        <div>
            <a class="col-1" href="Login.html" style="float: right">Login</a>
            <a href="Register.html" style="float: right">Register</a>
        </div>

    </div>
</div>
<div id="placeholder"> </div>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        stickyNavbar();
    });

    window.onscroll = function () {
        stickyNavbar();
    };

    var navbar = document.getElementById("navbar");
    var placeholder = document.getElementById("placeholder");
    var sticky = navbar.offsetTop;

    function stickyNavbar() {
        if (window.scrollY >= sticky) {
            navbar.classList.add("sticky");
            placeholder.style.display = "block";
            placeholder.style.height = navbar.offsetHeight + "px";
        } else {
            navbar.classList.remove("sticky");
            placeholder.style.display = "none";
        }
    }
</script>
<h1>Registration</h1>
<form action="add_user.php" method="post" enctype="multipart/form-data">
    Username: <input type="text" name="Username" required><br>
    Password: <input type="password" name="Password" required><br>
    email: <input type="text" name="email" required><br>
    Tel: <input type="text" name="Tel" required><br>
    Location: <input type="text" name="Location" required><br>
    <input type="submit" name="submit" value="Register">
</form>



<footer class="col-12">
    <a>doplnit kontakty, atd.</a>
</footer>
</body>
</html>