<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'conn.php';?>
    <?php include 'logindata.php';?>
    <?php include 'add_user.php';?>
    <link rel="stylesheet" href="navbar.css">

    <style>

    </style>
</head>
<body>



<div id="navbar" style="top: 0">
    <div  style="margin: auto; padding-bottom: 1px">
        <a style="float: left" href="Index.php">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
        <a style="float: right" href="Profile.php">
            <img src="mal.png" alt="MyAnimeList"  style="height: 55px; width: 130px;" >
        </a>
    </div>
    <div class="col-12">
        <div  class="dropdown">
            <button class="dropbtn">Anime
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content" >
                <a href="SearchGendre.html">Anime search</a>
                <a href="TopAnime">Top anime</a>
                <a href="NewAnime">New anime</a>
            </div>
        </div>

        <a href="#">About us</a>
        <a href="#">Help</a>
        <div>
            <a class="col-1" href="Login.html" style="float: right">Login</a>
            <a href="Register.html" style="float: right">Register</a>
        </div>

    </div>
</div>
<div id="placeholder"> </div>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        stickyNavbar();
    });

    window.onscroll = function () {
        stickyNavbar();
    };

    var navbar = document.getElementById("navbar");
    var placeholder = document.getElementById("placeholder");
    var sticky = navbar.offsetTop;

    function stickyNavbar() {
        if (window.scrollY >= sticky) {
            navbar.classList.add("sticky");
            placeholder.style.display = "block";
            placeholder.style.height = navbar.offsetHeight + "px";
        } else {
            navbar.classList.remove("sticky");
            placeholder.style.display = "none";
        }
    }
</script>
<?php
session_start();

session_destroy();

echo "<h1>Welcome, ".$_SESSION['username']."</h1>";

?>
<div>
    <div class="col-4">
        <a><img src="139318.jpg"></a>
        <h3>Profile picture</h3>
    </div>
    <div class="col-4">
        <a>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut beatae mollitia rerum! A eum facere harum iure nulla praesentium reiciendis sapiente sed. Adipisci fugit molestias, quibusdam ratione sint tenetur voluptates?</a>
    </div>
    <div class="col-4">
        <table>

        </table>
    </div>
</div>
<div>
    <h2 class="col-12">Favorite</h2>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
</div>
<div>
    <h2 class="col-12">All anime</h2>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
</div>


<footer class="col-12">
    <a>doplnit kontakty, atd.</a>
</footer>
</body>
</html>