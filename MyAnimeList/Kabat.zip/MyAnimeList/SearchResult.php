<!DOCTYPE html>
<html>
<head>
    <title>SearchResult</title>
    <link rel="stylesheet" href="navbar.css">
    <?php include 'conn.php';?>
    <style>

    </style>
</head>
<body>
<a href="Mainpage.html">
    <img src="mal.png" alt="MyAnimeList"  style="height: 70px; width: 200px;" >
</a>

<div class="navbar" style="top: 0">
    <div class="dropdown">
        <button class="dropbtn">Anime
            <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-content">
            <a href="animesearch.html">Anime search</a>
            <a href="#">Top anime</a>
            <a href="#">New anime</a>
        </div>
    </div>
    <a href="#">Updates</a>
    <a href="#">About us</a>
    <a href="#">Help</a>
    <a href="#" style="float: right">search TBA</a>
</div>
<header>
    <h1>Gendre</h1>
</header>
<div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
</div>
<div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
</div>
<div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
    <div class="col-2">
        <a><img src="139318.jpg"></a>
        <h3>Nazev</h3>
    </div>
</div>


<footer class="col-12">
    <a>doplnit kontakty, atd.</a>
</footer>
</body>
</html>