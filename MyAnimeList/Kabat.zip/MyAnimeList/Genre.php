<?php
session_start();

include 'conn.php';

if(isset($_POST['submit'])) {
    $Search = $_POST['submit'];
    $sql = "SELECT idGenre FROM Genre WHERE GName= '$Search'";
    $result = $conn->query($sql);
    if ($result->num_rows == 1){
        $row=$result->fetch_assoc();
        $IDGen=$row['idGenre'];

        $sql = "SELECT Anime_idAnime FROM Anime_has_Genre WHERE Genre_idGenre= '$IDGen'";
        $result = $conn->query($sql);
        //1 2 3 .... FUNGUJE
        if ($result->num_rows > 0) {
// row id nema vliv
//            $row=$result->fetch_assoc();
            while ($row = $result->fetch_assoc()) {
                $IDAni=$row['Anime_idAnime'];
                $sql1 = "SELECT idAnime, Name FROM Anime WHERE idAnime= '$IDAni'";
                $result1 = $conn->query($sql1);
                $row1=$result1->fetch_assoc();
                echo "<option value=\"" . $row1["idAnime"] . "\">" . $row1["Name"] . "</option>";

            }
//            $sql = "SELECT idAnime, Name FROM Anime WHERE idAnime= '$IDAni'";
//            $result = $conn->query($sql);
//            while ($row = $result->fetch_assoc()) {
//
//                echo "<option value=\"" . $row["idAnime"] . "\">" . $row["Name"] . "</option>";
//
//            }



            while ($row = $result->fetch_assoc()) {

            }
            $_SESSION['name'] = $result;
            echo "<p>Name, ".$_SESSION['name']."</p>";
            echo '<br> <a href="SearchResult.php">click here to continue</a> <br>';

        } else {
            echo "No data found in the database.";
        }
    }



}
else {
    echo "database error.";
}




$conn->close();

?>
