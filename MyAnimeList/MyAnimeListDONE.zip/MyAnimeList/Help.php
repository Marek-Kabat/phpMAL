<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include 'conn.php';?>

    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="style.css">

    <style>

    </style>
</head>
<body>
<?php include 'navbar.php';?>

<h1>Help</h1>
<p>Hello! <br> If you need help with anything regarding this website you can contact us at: Support@itdoesntexist.com <br> Thank you!</p>


<footer class="col-12">
    <a>Support@itdoesntexist.com</a>
</footer>
</body>
</html>